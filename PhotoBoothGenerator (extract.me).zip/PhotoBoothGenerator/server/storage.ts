import { photoStrips, type PhotoStrip, type InsertPhotoStrip } from "@shared/schema";

export interface IStorage {
  createPhotoStrip(strip: InsertPhotoStrip): Promise<PhotoStrip>;
  getPhotoStrip(id: number): Promise<PhotoStrip | undefined>;
}

export class MemStorage implements IStorage {
  private photoStrips: Map<number, PhotoStrip>;
  private currentId: number;

  constructor() {
    this.photoStrips = new Map();
    this.currentId = 1;
  }

  async createPhotoStrip(strip: InsertPhotoStrip): Promise<PhotoStrip> {
    const id = this.currentId++;
    const photoStrip: PhotoStrip = {
      ...strip,
      id,
      createdAt: new Date()
    };
    this.photoStrips.set(id, photoStrip);
    return photoStrip;
  }

  async getPhotoStrip(id: number): Promise<PhotoStrip | undefined> {
    return this.photoStrips.get(id);
  }
}

export const storage = new MemStorage();
