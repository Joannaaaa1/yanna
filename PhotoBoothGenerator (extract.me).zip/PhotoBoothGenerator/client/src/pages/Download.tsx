import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { usePhotoStore } from "@/lib/photoStore";
import { PhotoStrip } from "@/components/PhotoStrip";
import { Download as DownloadIcon, Home } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function Download() {
  const { id } = useParams();
  const { toast } = useToast();

  const { data: photoStrip, isLoading, error } = useQuery({
    queryKey: ['photoStrip', id],
    queryFn: async () => {
      const response = await fetch(`/api/photo-strips/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch photo strip');
      }
      return response.json();
    },
    enabled: !!id,
    retry: 3
  });

  if (isLoading) {
    return <div className="min-h-screen bg-background p-8 flex items-center justify-center">Loading...</div>;
  }

  if (error || !photoStrip) {
    return <div className="min-h-screen bg-background p-8 flex items-center justify-center">Failed to load photo strip</div>;
  }

  const handleDownload = () => {
    const canvas = document.querySelector<HTMLCanvasElement>('#photo-strip');
    if (!canvas) {
      toast({
        variant: "destructive",
        title: "Download failed",
        description: "Canvas not found"
      });
      return;
    }

    try {
      // Force a high-quality PNG
      const dataUrl = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `photo-strip-${id}.png`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Download failed",
        description: "Please try again"
      });
    }
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl font-bold mb-8">Your Photo Strip is Ready!</h1>
        <div className="mb-8">
          <PhotoStrip
            photos={photoStrip.photos}
            frameColor={photoStrip.frameColor}
            showDate={photoStrip.showDate === "true"}
          />
        </div>
        <div className="flex justify-center gap-4">
          <Button 
            variant="outline" 
            onClick={() => {
              usePhotoStore.getState().clearPhotos();
              window.location.href = '/';
            }}
          >
            <Home className="mr-2" /> New Strip
          </Button>
          <Button onClick={handleDownload}>
            <DownloadIcon className="mr-2" /> Download
          </Button>
        </div>
      </div>
    </div>
  );
}