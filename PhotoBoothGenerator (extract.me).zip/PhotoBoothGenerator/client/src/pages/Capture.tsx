import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { CameraView } from "@/components/CameraView";
import { usePhotoStore } from "@/lib/photoStore";
import { Camera, Loader2, FlipHorizontal } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Capture() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { addPhoto, photos } = usePhotoStore();
  const [capturing, setCapturing] = useState(false);
  const [filter, setFilter] = useState("none");

  const handleCapture = async (photoData: string) => {
    if (!photoData) return;
    setCapturing(true);
    try {
      addPhoto(photoData);
      if (photos.length >= 2) {
        navigate("/customize");
      } else {
        toast({
          title: `Photo ${photos.length + 1} captured!`,
          description: `${3 - photos.length} photos remaining...`
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to capture photo",
        description: "Please try again"
      });
    }
    setCapturing(false);
  };

  const filters = [
    { name: "None", value: "none" },
    { name: "Grayscale", value: "grayscale" },
    { name: "Sepia", value: "sepia" },
    { name: "Blur", value: "blur" }
  ];

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto grid grid-cols-3 gap-8">
        <div className="col-span-2">
          <h1 className="text-4xl font-bold mb-8">Take Your Photos</h1>
          <CameraView onCapture={handleCapture} filter={filter} />
          <div className="mt-4 flex flex-wrap gap-2">
            {filters.map((f) => (
              <Button
                key={f.value}
                variant={filter === f.value ? "default" : "outline"}
                onClick={() => setFilter(f.value)}
              >
                {f.name}
              </Button>
            ))}
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-4">Preview Strip</h2>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="aspect-video bg-muted rounded-lg overflow-hidden"
              >
                {photos[i] && (
                  <img
                    src={photos[i]}
                    alt={`Photo ${i + 1}`}
                    className="w-full h-full object-cover"
                  />
                )}
              </div>
            ))}
          </div>
          <div className="mt-8 flex justify-center gap-4">
            <Button
              size="lg"
              onClick={() => {
                const webcam = document.querySelector('video');
                if (webcam) {
                  const canvas = document.createElement('canvas');
                  canvas.width = webcam.videoWidth;
                  canvas.height = webcam.videoHeight;
                  const ctx = canvas.getContext('2d');
                  if (ctx) {
                    ctx.drawImage(webcam, 0, 0);
                    const photoData = canvas.toDataURL('image/jpeg');
                    handleCapture(photoData);
                  }
                }
              }}
              disabled={capturing}
            >
              {capturing ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Camera className="mr-2 h-4 w-4" />
              )}
              Capture ({photos.length}/3)
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}