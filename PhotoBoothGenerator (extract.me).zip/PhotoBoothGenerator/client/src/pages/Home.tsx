import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Camera } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 to-purple-600 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-white mb-8">Pixiebooth</h1>
        <p className="text-xl text-white mb-12">Create beautiful photo strips in seconds</p>
        <Link href="/capture">
          <Button size="lg" className="bg-white text-pink-600 hover:bg-pink-100">
            <Camera className="mr-2" /> Start Capturing
          </Button>
        </Link>
      </div>
    </div>
  );
}
