import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ColorPickerProps {
  color: string;
  onChange: (color: string) => void;
}

const colors = [
  { name: "Pink", value: "#FF69B4" },
  { name: "Purple", value: "#9370DB" },
  { name: "Blue", value: "#4169E1" },
  { name: "Green", value: "#3CB371" },
  { name: "Yellow", value: "#FFD700" },
  { name: "Orange", value: "#FFA500" },
  { name: "Red", value: "#FF4136" },
];

export function ColorPicker({ color, onChange }: ColorPickerProps) {
  return (
    <div className="flex flex-wrap gap-2 mt-2">
      {colors.map((c) => (
        <Button
          key={c.value}
          variant="outline"
          className={cn(
            "w-12 h-12 rounded-full p-0 relative",
            color === c.value && "ring-2 ring-primary ring-offset-2"
          )}
          style={{ backgroundColor: c.value }}
          onClick={() => onChange(c.value)}
          title={c.name}
        >
          <span className="sr-only">{c.name}</span>
        </Button>
      ))}
    </div>
  );
}
